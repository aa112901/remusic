package com.wm.remusic.json;

/**
 * Created by wm on 2016/4/15.
 */
public class RadioNetInfo {

    /**
     * channelid : 11373552
     * itemid : 13015515
     * album_id : 13015216
     * title : 我从不怕爱错，就怕没爱过
     * pic : http://a.hiphotos.baidu.com/ting/pic/item/d8f9d72a6059252dcbcd03a8339b033b5ab5b947.jpg
     * type : lebo
     * desc : 音乐
     */

    private String channelid;
    private String itemid;
    private String album_id;
    private String title;
    private String pic;
    private String type;
    private String desc;

    public String getChannelid() {
        return channelid;
    }

    public void setChannelid(String channelid) {
        this.channelid = channelid;
    }

    public String getItemid() {
        return itemid;
    }

    public void setItemid(String itemid) {
        this.itemid = itemid;
    }

    public String getAlbum_id() {
        return album_id;
    }

    public void setAlbum_id(String album_id) {
        this.album_id = album_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}

package com.wm.remusic.request;

import com.google.gson.annotations.SerializedName;
import com.wm.remusic.lastfmapi.models.LastfmArtist;

public class ZhuanLanAuthor {

    private static final String NAME = "name";

    @SerializedName(NAME)
    public String mName;


}
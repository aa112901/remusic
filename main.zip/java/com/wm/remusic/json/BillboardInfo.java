package com.wm.remusic.json;

/**
 * Created by wm on 2016/5/14.
 */
public class BillboardInfo {
    public String title;
    public String author;
    public String id;
}

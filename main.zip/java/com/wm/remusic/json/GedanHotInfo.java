package com.wm.remusic.json;

/**
 * Created by wm on 2016/4/15.
 */
public class GedanHotInfo {

    /**
     * listid : 6509
     * pic : http://a.hiphotos.baidu.com/ting/pic/item/8718367adab44aedfd9dbe49b41c8701a08bfb48.jpg
     * listenum : 60009
     * collectnum : 513
     * title : 那些念念不忘的电影插曲
     * tag : 电影,电视剧
     * type : gedan
     */

    private String listid;
    private String pic;
    private String listenum;
    private String collectnum;
    private String title;
    private String tag;
    private String type;

    public String getListid() {
        return listid;
    }

    public void setListid(String listid) {
        this.listid = listid;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getListenum() {
        return listenum;
    }

    public void setListenum(String listenum) {
        this.listenum = listenum;
    }

    public String getCollectnum() {
        return collectnum;
    }

    public void setCollectnum(String collectnum) {
        this.collectnum = collectnum;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
